import anvil.server
# This is a module.
# You can define variables and functions here, and use them from any form. For example, in a top-level form:
#
#    from .Main_Menu.ORDER_NOW.Create_A_Pizza import Module1
#
#    Module1.say_hello()
#

def say_hello():
  print("Hello, world")
